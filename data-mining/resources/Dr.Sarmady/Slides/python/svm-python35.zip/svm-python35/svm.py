import numpy as np

def buildData(filename, featureCols, testRatio):
    f = open(filename)
    data = np.loadtxt(fname = f, delimiter = ',')
    np.random.shuffle(data)

    X = data[:, :featureCols]  # select columns 0:featureCols-1
    y = data[:, featureCols]   # select column  featureCols 

    n_points = y.size
    print ("Imported " + str(n_points) + " lines.")
    
    ### split into train/test sets
    split = int((1-testRatio) * n_points)
    X_train = X[0:split,:]
    X_test  = X[split:,:]
    y_train = y[0:split]
    y_test  = y[split:]

    return X_train, y_train, X_test, y_test

def buildClassifier(features_train, labels_train):
    from sklearn import svm

    clf = svm.SVC(kernel='rbf',C=1.0, gamma=0.1)
    clf.fit(features_train, labels_train)
    
    return clf
    
def checkAccuracy(clf, features, labels):
    from sklearn.metrics import accuracy_score

    pred = clf.predict(features)
    accuracy = accuracy_score(pred, labels)
    return accuracy
    
features_train, labels_train, features_test, labels_test = buildData("car-eval-data-1.csv", 6, 0.3)
clf           = buildClassifier(features_train, labels_train)
trainAccuracy = checkAccuracy(clf, features_train, labels_train)
testAccuracy  = checkAccuracy(clf, features_test, labels_test)
print ("Training Items: " + str(labels_train.size) + ", Test Items: " + str(labels_test.size))
print ("Training Accuracy: " + str(trainAccuracy))
print ("Test Accuracy: " + str(testAccuracy))

#i = 0
#while i < labels_test.size:
#  pred = clf.predict(features_test[i])
#  marker = " "
#  if labels_test[i] != pred:
#    marker = " *"
#  print ("F(" + str(i) + ") : " + str(features_test[i]) + " label= " + str(labels_test[i]) + " pred= " + str(pred) + marker)
#  i = i + 1
